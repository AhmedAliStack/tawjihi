import 'package:flutter/material.dart';

const Color primaryColor = Color(0xff051F20);
const Color secondaryColor = Color(0xff393939);
const Color mauveColor = Color(0xffA647A4);
const Color yellow = Color(0xffF4B82A);
const Color header = Color(0xff202020);
const Color borderMainColor = Color(0xffE7ECF3);
const Color containerColor = Color(0xffF9F9F9);
const List<Color> gradientButton = [mauveColor, yellow];
