class Statics {
  // static const registerUser = "REGISTER_USER";
  static const user = "USER";
  static const token = "TOKEN";
  static const allLists = "ALL_LISTS";
}
