part of 'splash_cubit.dart';

abstract class SplashState {}

class SplashInitial extends SplashState {}

class SuccessSplashState extends SplashState {}

class ErrorSplashState extends SplashState {}
