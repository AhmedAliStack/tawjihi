part of 'my_tests_cubit.dart';

abstract class MyTestsState {}

class MyTestsInitial extends MyTestsState {}
